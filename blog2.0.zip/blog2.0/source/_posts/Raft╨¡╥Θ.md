---
title: 金丝雀发布和集群初认识
date: 2023-03-05 22:35:51
tags: 
  - 容器云
  - 理论
category:
  - 运维
mathjax: true
---
# Raft协议

```shell
# 双主双从：假设一个节点挂了，其他节点是否可用？
Raft：保证大多数节点存活才可用，只要 > 1,集群至少大于3台！
```

### 实验：

```
1、将docker1停止，宕机！ 双主，另外一个节点也无法使用。
```

![](https://img-blog.csdnimg.cn/20200817102811431.png#pic_center)

```
可以将其他节点离开集群，docker swarm leave
```

![](https://img-blog.csdnimg.cn/202008171034151.png#pic_center)

work就是工作的，管理节点用来操作！

![](https://img-blog.csdnimg.cn/20200817104128335.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ZhbmppYW5oYWk=,size_16,color_FFFFFF,t_70#pic_center)

```
集群可用，至少保证有3个主节点。至少有1台管理节点存活。
Raft协议：保证大多数结点存活，才可以使用，高可用！
```

# 体会

弹性、扩缩容！集群！

```
告别docker run!
docker-compose up! 启动一个项目，单机！
集群：swarm
docker swarm service

容器 --> 服务！
redis =3份！ 容器！
集群：高可用！ web-->redis（3台，分布在不同的机器上！）
容器 ==> 服务！ ==> 副本！
redis => 10个副本！（同时开启10个redis容器）
```

## docker service

```
[root@admin /]# docker service --help
Usage:  docker service COMMAND
Manage services
Commands:
  create      Create a new service
  inspect     Display detailed information on one or more services
  logs        Fetch the logs of a service or task
  ls          List services
  ps          List the tasks of one or more services
  rm          Remove one or more services
  rollback    Revert changes to a service's configuration
  scale       Scale one or multiple replicated services
  update      Update a service

Run 'docker service COMMAND --help' for more information on a command.
```

灰度发布（金丝雀发布）

![](https://img-blog.csdnimg.cn/20200817124458860.png#pic_center)

```
docker run 容器启动！ 不具有扩缩容器
docker service 服务！ 具有扩缩容器，滚动更新！
```

#### 查看服务 docker service ps

![](https://img-blog.csdnimg.cn/20200817124725880.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ZhbmppYW5oYWk=,size_16,color_FFFFFF,t_70#pic_center)

```
此时我们会发现在docker1启动的服务
在docker1执行docker ps找不到容器，在docker3却可以找到。

可以通过docker service update --replicas 来增加副本
例如：
	#docker service update --replicas 3 mynginx
此时会在节点中随机添加副本
	#docker service update --replicas 1 mynginx
此时会动态回滚，做到只留一个副本
```

> **一个服务，集群中任意的节点都可以访问，服务可以有多个副本动态扩缩容**

#### 弹性、扩缩容

```shell
实现服务的高可用，服务器的高可用
扩缩容的两种方式:
# 一 update
	#docker service update --replicas 3 mynginx
此时会在节点中随机添加副本
	#docker service update --replicas 1 mynginx
此时会动态回滚，做到只留一个副本

# 二 scale
	# docker service scale mynginx=3
	mynginx scaled to 3
	overall progress: 3 out of 3 tasks 
	1/3: running   
	2/3: running   
	3/3: running   
	verify: Service converged 
	# docker service ls
	ID             NAME      MODE         REPLICAS   IMAGE          	PORTS
	obfc5bmfwh4j   mynginx   replicated   3/3        nginx:latest   	*:8888->80/tcp
```

## 移除服务

```shell
# docker service rm mynginx
```

## 概念的总结

**swarm**

> **集群的管理和编号，docker可以初始化一个swarm集群，其他结点可以加入。（管理，工作者）**

**Node**

> **就是一个docker结点，多个结点就组成了一个网络集群（管理、工作者）**

**Service**

> **任务，可以在管理结点或者工作结点来运行。核心，用户访问。**

**Task**

> **容器内的命令、细节任务！**

![](https://img-blog.csdnimg.cn/2020081713583960.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ZhbmppYW5oYWk=,size_16,color_FFFFFF,t_70#pic_center)

> **service**

![](https://img-blog.csdnimg.cn/20200817135939796.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ZhbmppYW5oYWk=,size_16,color_FFFFFF,t_70#pic_center)

> **服务副本和全局服务**

![](https://img-blog.csdnimg.cn/20200817141046744.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2ZhbmppYW5oYWk=,size_16,color_FFFFFF,t_70#pic_center)

> **拓展： 网络模式 "PublishMode":"ingress"**

```
Swarm:
Overlay:
ingress:特殊的Overlay网络！负载均衡的功能！ipvs vip！
```

#### overlay让集群的网络成为一个整体

# docker  stack

```
docker-compose 单机部署项目
docker stack 集群部署
 
# 单机
docker-compose up -d wordpress.yaml
# 集群
docker stack deploy wordpress.yaml
```

#  docker secret

```
安全！配置密码！证书！
 
[root@iZ2ze58v8acnlxsnjoulk5Z ~]# docker secret --help
 
Usage:  docker secret COMMAND
 
Manage Docker secrets
 
Commands:
  create      Create a secret from a file or STDIN as content
  inspect     Display detailed information on one or more secrets
  ls          List secrets
  rm          Remove one or more secrets
```

# docker config

```
配置！
[root@iZ2ze58v8acnlxsnjoulk5Z ~]# docker config --help
 
Usage:  docker config COMMAND
 
Manage Docker configs
 
Commands:
  create      Create a config from a file or STDIN
  inspect     Display detailed information on one or more configs
  ls          List configs
  rm          Remove one or more configs

```

