---
title: 爬虫入门
date: 2023-03-08 20:00:00
tags:
  - Python
  - 爬虫
  - 理论
category:
  - 开发
mathjax: true
---
# Python爬虫

> **什么是爬虫？**

- 通过编写程序，模拟浏览器上网，然后让其去互联网上抓取数据的过程。

> **合法性**

- 在法律中是不被禁止的
- 具有违法风险
- 善意爬虫 / 恶意爬虫

> **风险性（红线）**

- 干扰了被访问网站的正常运营
- 抓取受法律保护特定类型数据或信息

> **避免**

- 时常优化自己的程序，避免干扰网站正常运营
- 使用过程中，爬取到数据需要审查抓取到的内容

## 分类

### 通用爬虫

> 抓取系统重要组成部分，抓取的是一整张页面

### 聚集爬虫

> 建立在通用爬虫的基础之上，抓取的是页面中特定的局部内容

### 增量式爬虫

> 检测网站中数据更新的情况，只会抓取网站中最新更新的数据

## 爬虫的矛与盾

- > **反爬机制**
  > 通过指定相应的策略或者技术手段，防止爬虫程序进行网站数据爬取

- > **反反爬策略**
  > 爬虫程序通过指定相关的策略或者技术手段，破解门户网站中的限制手段，从而获取数据

## 反爬机制1

**robots.txt**

> **君子协议，规定了网站中哪些数据可以被爬取，可不遵守**

> **通过访问 域名/robots.txt 来查看对应网站的robots协议**

## HTTP&&HTTPS

- **HTTP协议**

  > 概念：服务器和客户端进行数据交互的一种形式

  **常用请求头信息**

  - **User-Agent**：请求载体的身份标识

  - **Connection**：请求完毕后是断开连接还是保持连接

  

  **常用响应头信息**

  - **Content-Type**：服务器响应回客户端的数据类型

- **HTTPS协议**

  > 安全的超文本传输协议，数据加密

- **加密方式**

  - 对称密钥加密
  - 非对称密钥加密
  - 证书密钥加密

## 实验开始

### requests模块

> Python中原生的一款基于网络请求的模块，功能强大，效率高。

> 作用：模拟浏览器发起请求

###  How to use?

- **指定url**
- **发起请求**
- **获取响应数据**
- **持久化存储**

> **环境安装**：pip install requests

### 案例1

```python
案例1
# 爬取百度首页数据
# 导包
import requests

# 指定URL
url = 'https://www.baidu.com'
# 发起请求
# get方法会返回一个响应对象，用response来接收对象
response = requests.get(url=url)
# 获取响应数据，text返回的是字符串形式的响应数据
text = response.text
print(text)
# 持久化存储
with open('D:/Pycharm/笔记/baidu.html','w',encoding='utf-8') as fp:
    fp.write(text)
    print('爬取结束!!!')
```

> **UA检测**：门户网站的服务器会检测对应请求的载体身份标识，如果检测到请求的载体是浏览器，则为正常请求，反之则为不正常请求

> **UA伪装**：让爬虫对应的载体请求伪装成某一款浏览器

### 案例2

```python
案例2
本案例涉及 UA检测&&UA伪装
# 制作一个简易的网页搜索
# 导包
import requests

# 指定URL
url = 'https://www.baidu.com/s?'

# 处理URL附带的参数，封装到字典中
search = input('please input your search:')
param = {
    'wd':search				该参数来自于网页搜索内容上方url后附带的参数
}
# UA伪装，将浏览器的身份标识写入字典，伪装到爬虫程序中
header = {
    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
}

# 发起请求
response = requests.get(url=url,params=param,headers=header)

# 获取响应头
text = response.text
print(text)

# 持久化存储
fileName = search + '.html'
with open(fileName,'w',encoding='utf-8') as fp:
    fp.write(text)
```

### 案例3

```python
案例3
本案例涉及post请求 && 获取响应头后的处理 && json的数据
# 破解百度翻译
# 导包
import requests

# 指定URL
url = 'https://fanyi.baidu.com/sug'

# 发送请求
## UA伪装
header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
}
# 设置参数（单词）
word = input('please input your word:')
data = {
    'kw': word
}
response = requests.post(url=url,data=data,headers=header)

# 获取响应头,response.json()方法返回的是obj，如果确认服务器返回的是json数据则可以使用改方法
obj = response.json()
print(obj)
print(obj['data'][0]['v'])
```

### 案例4

```python
案例4
本案例涉及 get参数修改
# 获取豆瓣电影排行
# 导包
import requests

# 指定URL
url = 'https://movie.douban.com/j/chart/top_list?'

# 发送请求
## UA伪装
header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
}
## 设置参数
param = {
    'type': '24',
    'interval_id': '100:90',
    'action': '',
    'start': '0',  # 从第几部电影开始取值
    'limit': '10'   # 一次请求取多少电影
}

response = requests.get(url=url,params=param,headers=header)
obj = response.json()
print(obj)
```

## 聚焦爬虫

> **爬取页面中指定的页面内容**

#### 编码流程

- **指定URL**
- **发起请求**
- **获取响应数据**
- **数据解析**
- **持久化存储**

### 数据解析分类

- **正则**
- **bs4**
- **🔺xpath**

### 数据解析原理概述

- **解析的局部文本内容都会在标签之间或者标签的属性中进行存储**
- **进行指定标签的定位**
- **标签或者标签对应的属性中存储的数据进行提取**

#### 案例1

```python
# 获取一张图片
# 导包
import requests

# 指定URL
url = 'https://w.wallhaven.cc/full/j3/wallhaven-j3p2oy.jpg'
header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53',
}

# 发送请求
img = requests.get(url=url,headers=header).content

# 数据解析


# 持久化存储
with open('D:/Pycharm/笔记/123.jpg','wb') as fp:
    fp.write(img)
```

#### 案例2（正则）

```python
# 🔺本方法适用于匹配js代码中的内容，因为xpath只能匹配html文件中的内容
# 导包
import requests
import re

# 指定URL
url = 'https://wallhaven.cc/search?categories=111&purity=100&sorting=date_added&order=desc'
header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53',
}

# 发送请求
page_text = requests.get(url=url,headers=header).text

# 数据解析
img_list  = []
ex = '<section class="thumb-listing-page">.*?<li>(.*?)</li>.*?</section>'
img_list.append(re.findall(ex,page_text,re.S))
print(img_list)

# 持久化存储

```

#### 案例3（BS4）python独有

```
此案例暂时不使用
```

#### 案例4（xpath）

- **xpath解析原理**：

  > 实例化一个etree的对象，且将需要被解析的页面源码数据加载到该对象中
  >
  > 调用etree对象中的xpatch方法结合xpath表达式定位标签和内容捕获

> **解析器安装**:pip install lxml

- **如何实例化一个etree对象？from lxml import etree**

  - 将本地的html文档中源码数据加载到etree对象中

    > **etree.parse(filePath)**

  - 可以将从互联网上的页面源码数据加载到对象中

    > **etree.HTML('page_text')**

- **xpath('xpath表达式')**

  - **/  表示的是从根节点开始定位，表示一个层级**
  - **//表示多个层级，可以表示从任意位置开始定位**

- **取值文本或取值属性**

  - **取值文本：text()**
  - **取值属性：@属性名**

```python
# 实例化对象
tree = etree.HTML(page_html)
# xpath返回一个列表
r = tree.xpath('/html/body/div')
r = tree.xpath('/html//div')
r = tree.xpath('//div')
# 属性定位
r = tree.xpath('//div[@class="song"]')
# 获取第2个p标签，该索引从1开始
r = tree.xpath('//div[@class="song"]/p[2]')

# 取值文本内容
r = tree.xpath('//div[@class="tang"]//a/text()')
# 此时该文本存在列表中，如果需要值则
r = tree.xpath('//div[@class="tang"]//a/text()')[0]

# 取属性
r = tree.xpath('//div[@class="tang"]//a/@href')
# 此时该属性存在列表中，如果需要值则
r = tree.xpath('//div[@class="tang"]//a/@href')[0]

# 小案例1
# 导包
from lxml import etree
import requests

url = 'https://www.baidu.com'

header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53',
}

response = requests.get(url=url,headers=header)
pag_html = response.text

tree = etree.HTML(pag_html)
r = tree.xpath('/html/head/title')
r = tree.xpath('//div[@class="title-text c-font-medium c-color-t"]/@aria-label')[0]

print(r)
```

##### 案例4.1

```python
# 实现二手房的名称获取 本章包含 etree的实例化&&xpath属性查找
# 导包
import requests
from lxml import etree

# 指定URL
url = 'https://fz.58.com/ershoufang/?PGTID=0d100000-0013-031a-c138-7db06006f80a&ClickID=2'

# 发送请求
## UA伪装
header = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36 Edg/101.0.1210.53'
}

# 获取响应数据
page_html = requests.get(url=url,headers=header).text
## 数据解析
### 实例化etree对象
tree = etree.HTML(page_html)
r = tree.xpath('//section[@class="list-left"]//div[@class="property-content"]//h3/@title')

print(r)

Tip:XPATH也可以通过设置多个表达式来选择多个标签
    xpath('xpath表达式1 | xpath表达式2')
```

##### 案例4.2

```python
# 导包
import requests
from lxml import etree

# 指定URL
url = 'https://sc.chinaz.com/jianli/free.html'
header = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36 Edg/102.0.1245.30'
}

# 获取响应数据（网页）
response = requests.get(url=url,headers=header)
page_html = response.text

# 先获取免费模板的详情页链接
page_tree = etree.HTML(page_html)
## 选到li标签
tree = page_tree.xpath('//div[@class="sc_warp  mt20"]//div[@id="container"]/div')
list_src = []
list_name = []
for r in tree:
    list_src.append('https://' + r.xpath('./a/@href')[0])
    list_name.append(r.xpath('./p/a/text()')[0] + '.rar')

print(list_name)
```

## 反爬与反反爬

### 验证码

- **识别验证码方式**：

  - 人工肉眼识别

  - 🔺第三方自动识别

```python
# 本案例实现了抓包验证码地址，并通过html的形式让他在网页中显示出来，从而实现肉眼识别验证码，第三方验证码获取需要money
# 导包
import requests
import os
from lxml import etree

# 指定URL
url = 'https://jwweb.fjny.edu.cn/ZNPK/KBFB_ClassSel.aspx'
header = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36 Edg/102.0.1245.30'
}

# 发送请求
page_html = requests.get(url=url,headers=header).text

# 数据解析
page_html_tree = etree.HTML(page_html)
getCode_src = page_html_tree.xpath('//*[@id="imgCode"]/@src')[0]
getCode_src = 'https://jwweb.fjny.edu.cn/' + getCode_src[2::1]

start = '<img src="'
source = getCode_src
end = '">'

with open('getCode.html','w',encoding='utf-8') as fp:
    fp.write(start + source + end)
os.system('start "" "getCode.html"')

setCode = input('please input you code:')

# 返回验证码
url_post = 'https://jwweb.fjny.edu.cn/ZNPK/KBFB_ClassSel_rpt.aspx'

data = {
    'Sel_XNXQ': '20211',
    'txtxzbj': '',
    'Sel_XZBJ': '2020041202',
    'type': '1',
    'txt_yzm': setCode
}
headers = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36 Edg/102.0.1245.30',
    'cookie' : 'name=value; myCookie=; ASP.NET_SessionId=45gm5ww2g43vne35zb4mzhso; name=value'
}
post_page_html = requests.post(url=url_post,data=data,headers=headers).text
print(post_page_html)
```

## 基于Cookie的登入操作

> **由于发起的第二次基于登入后请求的时候，服务器端并不知道该请求已经基于登入状态下的请求**

**cookie**：用于让服务器记录客户端响应状态

```python
手动cookie获取（不推荐）需要自己打开浏览器然后登入获取...

🔺自动cookie获取（推荐）
	cookie值来源？
		模拟登入时服务器返回的
	session会话对象：
		作用：可以进行请求发送，如果请求过程中产生cookie则会被自动存储在session中

# 创建session对象: session = requests.session()
# 使用session对象进行模拟登入请求的发送
# session对象对个人主页对应的get请求发送（携带cookie）

# 创建session对象
session = requests.session()
# 登入操作，同时保存cookie到session对象中
page_html = sessin.get(url=url,params=param,headers=header)
# 进行登入成功后的操作
all_pge_html = sessin.post(url=url,data=data,headers=header)

实例：
# 导包
import requests
from lxml import etree

# 指定URL
url = 'https://www.lovejay.top/wp-admin/admin-ajax.php'

header = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36 Edg/102.0.1245.39'
}
data = {
    'action': 'user_login',
    'username': '123@163.com',
    'password': '123456789',
    'rememberme': 'forever',
    'redirect_to': ''
}
session = requests.session()
session.post(url=url,data=data,headers=header)
url2 = 'https://www.lovejay.top/user/settings'
test = session.get(url=url2,headers=header).text
print(test)
```

## 代理IP

> **防止被服务器封**IP

- **什么是代理IP?**
  - 代理服务器

- **作用**
  - 突破自身IP访问的限制
  - 可以隐藏真实IP，防止攻击

- **代理网站**
  - *** (过于先进，不方便展示)
  - **** (过于先进，不方便展示)
  - **** (过于先进，不方便展示)

## 高性能异步爬虫

> **在爬虫中使用异步实现高性能的数据爬取**

```python
# 传统多数据爬取案例

import requests

header = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36 Edg/102.0.1245.30'
}
urls = [
    'https://w.wallhaven.cc/full/g7/wallhaven-g7633l.jpg',
    'https://w.wallhaven.cc/full/72/wallhaven-72vdyv.jpg',
    'https://w.wallhaven.cc/full/pk/wallhaven-pk1rqe.jpg',
    'https://w.wallhaven.cc/full/9m/wallhaven-9mv3jd.png'
]

def get_content(url):
    print('正在爬取: ',url)
    response = requests.get(url=url,headers=header).content
    return response

def get_content_len(content):
    print('数据长度为: ',len(content))

for url in urls:
    get_content_len(get_content(url))
    
正在爬取:  https://w.wallhaven.cc/full/g7/wallhaven-g7633l.jpg
数据长度为:  1682986
正在爬取:  https://w.wallhaven.cc/full/72/wallhaven-72vdyv.jpg
数据长度为:  19184937
正在爬取:  https://w.wallhaven.cc/full/pk/wallhaven-pk1rqe.jpg
数据长度为:  19986695
正在爬取:  https://w.wallhaven.cc/full/9m/wallhaven-9mv3jd.png
数据长度为:  1583415
# 此时每次都需要等待前面的get请求结束后才能进行下一项的操作，非常耗时
# 简略版
import time
name = ['aa','bb','cc','dd']
start_time = time.time()
def get_content(name):
    print('正在下载:' + name)
    time.sleep(2)
    print('下载成功:' + name)

for name in name:
    get_content(name)
end_time = time.time()
after = end_time - start_time
print(after)

正在下载:aa
下载成功:aa
正在下载:bb
下载成功:bb
正在下载:cc
下载成功:cc
正在下载:dd
下载成功:dd
耗时：8.03206753730774
```

```python
# 多数据异步爬取案例

# 多线程操作（不建议使用）
	好处：可以为相关阻塞的操作单独开启线程，可以实现异步执行
	弊端：无法无限制的开启多线程
# 进程池（适当使用）
	好处：可以降低系统对进程创建和销毁的一个频率，从而很好的降低系统资源的开销
    弊端：池中线程或进程数量是有上限的

# 进程池方法
import time
# 导入进程池模块对应的类
from multiprocessing.dummy import Pool

name = ['aa','bb','cc','dd']
start_time = time.time()
def get_content(name):
    print('正在下载:' + name)
    time.sleep(2)
    print('下载成功:' + name)

# 实例化一个进程池对象，同时进行4进程
pool = Pool(4)
# 将列表中的每一个元素传递给get_contene进行处理
pool.map(get_content,name)

end_time = time.time()
after = end_time - start_time
print(after)

正在下载:aa正在下载:bb
正在下载:cc正在下载:dd
        
下载成功:dd下载成功:aa
下载成功:cc下载成功:bb
耗时：2.016845226287842
```

## Selenium模块获取动态加载

> **当我们使用浏览器的抓包工具进行互联网抓包时，会非常的繁琐，此时我们就需要用到selenium模块来帮我们便捷的获取网站中动态加载的数据**
>
> **同时也可以便捷的模拟登入**

**selenium模块是基于浏览器自动化的模块**

### **流程**

- **环境安装**pip install selenium
- **下载浏览器驱动程序**[Microsoft Edge WebDriver - Microsoft Edge Developer](https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/)

> **将下载到的驱动程序放置在python目录中**

![](https://user-images.githubusercontent.com/93499895/173180713-990c5bbc-3eff-48a9-97fd-6da153735436.png)

- **实例化一个浏览器对象**

### Getting start

```python
案例1
from selenium import webdriver
from selenium.webdriver.edge.service import Service
# 实例化一个浏览器对象，一定要传入浏览器驱动程序
s = Service("msedgedriver.exe")
driver = webdriver.Edge(service=s)

driver.get('https://www.baidu.com')

# 由于我们使用的是最新版本的，所以我们可以简写为
from selenium import webdriver

edge = webdriver.Edge()

edge.get('https://www.bilibili.com')
```

#### 案例2（已淘汰）

```python
# 已淘汰！！！
# 让浏览器发起指定url的请求，通过浏览器来获取动态加载的数据
from selenium import webdriver
from selenium.webdriver.edge.service import Service
from lxml import etree
# 实例化一个浏览器对象，一定要传入浏览器驱动程序
service = Service('msedgedriver.exe')
edge = webdriver.Edge(service = service)
# 打开网页
edge.get('https://pixivic.com/')
# 获取网页源码数据
page_html = edge.page_source
# etree进行数据解析
tree = etree.HTML(page_html)
li_list = tree.xpath('//*[@id="app"]/div[1]/div[2]/div[2]/div/div/div[1]/div')

for li in li_list:
    href = li.xpath('.//div/img/@src')
    print(href)
# 退出浏览器
edge.quit()
```

#### 案例3

```python
# 实现哔哩哔哩搜索功能 本案例涉及xpath获取标签位置，以及click触发操作
from selenium import webdriver
import time

edge = webdriver.Edge()

edge.get('https://www.bilibili.com')

search_input = edge.find_element(by='xpath', value='//*[@id="nav-searchform"]/div[1]/input')
search_input.send_keys('test')

search = edge.find_element(by='xpath', value='//*[@id="nav-searchform"]/div[2]')
search.click()

time.sleep(5)
edge.quit()
```

#### 案例3.1

```python
# 本案例涉及 js控制和基本浏览器前进后退操作
from selenium import webdriver
import time

edge = webdriver.Edge()

edge.get('https://www.bilibili.com')

search_input = edge.find_element(by='xpath', value='//*[@id="nav-searchform"]/div[1]/input')
search_input.send_keys('test')

search = edge.find_element(by='xpath', value='//*[@id="nav-searchform"]/div[2]')
search.click()
#  执行一组js代码控制浏览器滚动条
edge.execute_script('window.scrollTo(0,document.body.scrollHeight)')
# 打开一个新的页面
edge.get('https://www.baidu.com')
time.sleep(2)
# 返回上一页
edge.back()
time.sleep(2)
# 返回后一页
edge.forward()
```

> 如果定位的标签存在iframe中，则不能直接使用find

```
edge.switch_to.frame('{name}') #切换浏览器标签作用域
edge.find_element(by='xxx',value='xxx')
```

#### 动作链

- **导包**from selenium.webdriver import ActionChains
- **实例化**

```
action = ActionChains(edge)
```

- **操作某一个div**

```
# 摁住某一个div
action.click_and_hold(div)
# 移动多少像素
# move_by_offset(x,y);x水平方向，y垂直方向
# perform()立即执行
action.move_by_offset(17,0).perform()
```

- **关闭动作链**

```
action.release()
```

### 无头浏览器 + 规避检测

> 解决浏览器弹出问题，实现无浏览器弹出的爬虫

#### 案例1

```python
# 实现edge实现无可视化界面
# 导入Options包
from selenium.webdriver.edge.options import Options
from selenium import webdriver
import time

# 创建对象
opt = Options()
# 配置参数
opt.add_argument("--headless")
opt.add_argument("--disbale-gpu")

# 将对象添加到edge浏览器中
edge = webdriver.Edge(options=opt)
edge.get('https://www.baidu.com')
print(edge.page_source)

time.sleep(3)
edge.quit()
```

#### 规避检测

```python
# 如何实现让selenium规避被检测的风险
# 导入Options包
from selenium.webdriver.edge.options import Options
from selenium import webdriver
import time

# 创建对象
opt = Options()
# 配置参数
opt.add_argument("--headless")
opt.add_argument("--disbale-gpu")
# 实现规避检测
opt.add_argument('--disable-blink-features=AutomationControlled')  <---- 这条命令实现规避服务器检测


# 将对象添加到edge浏览器中
edge = webdriver.Edge(options=opt)
edge.get('https://www.baidu.com')
print(edge.page_source)

time.sleep(3)
edge.quit()
```

> edge可直接复制的无头浏览器头&&导包

```
# 导入Options包
from selenium.webdriver.edge.options import Options
from selenium import webdriver

# 创建对象
opt = Options()
# 配置参数
opt.add_argument("--headless")
opt.add_argument("--disbale-gpu")
# 实现规避检测
opt.add_argument('--disable-blink-features=AutomationControlled')

# 实例化浏览器，将opt参数传入浏览器即可
```

## **延时等待**

```
在Selenium中，get()方法会在网页框架加载结束后结束执行，此时如果获取page_source ，可能并不是浏览器完全加载完成的页面.

如果某些页面有额外的Ajax请求，我们在网页惊代码中也不一定能成功获取到。所以，这里需要延时等待一定时间，确保节点已经加载出来
```



## 响应数据类型介绍

- **text （字符串）**
- **content（二进制）**
- **json()（对象）**

## 浏览器控制台

#### NetWork网络抓包

该选项主要用于抓取网络数据包，比如查看请求信息、响应信息等。它有三个常用选项卡，分别是 All、XHR、JS，其作用如下：

- All：抓取所有的网络数据包
- XHR：抓取所有异步加载的网络数据包
- JS：抓取所有的JS文件

#### 中文乱码

- **方案1**

  > **直接对拉取到的源码进行转编码格式**
  >
  > response.encoding = 'utf-8'

- **方案2（通用中文乱码的解决方案）**

  > **对发生乱码的地方进行转编码格式**
  >
  > name.encode('iso-8859-1').decode('gbk')

