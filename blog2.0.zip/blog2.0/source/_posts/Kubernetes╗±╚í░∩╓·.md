---
title: Kubernetes获取帮助
date: 2023-03-29 00:00:00
tags:
  - 容器云
  - 企业级应用
  - 理论
category:
  - 运维
mathjax: true
---
# Kubernetes获取帮助

## 传统命令行帮助

```shell
# 可以通过
# kubectl --help
kubectl controls the Kubernetes cluster manager.

 Find more information at: https://kubernetes.io/docs/reference/kubectl/overview/

Basic Commands (Beginner):
  create        Create a resource from a file or from stdin
  expose        Take a replication controller, service, deployment or pod and expose it as a new Kubernetes service
  run           Run a particular image on the cluster
  set           Set specific features on objects

Basic Commands (Intermediate):
  explain       Get documentation for a resource
  get           Display one or many resources
  edit          Edit a resource on the server
  delete        Delete resources by file names, stdin, resources and names, or by resources and label selector

Deploy Commands:
  rollout       Manage the rollout of a resource
  scale         Set a new size for a deployment, replica set, or replication controller
  autoscale     Auto-scale a deployment, replica set, stateful set, or replication controller

Cluster Management Commands:
  certificate   Modify certificate resources.
  cluster-info  Display cluster information
  top           Display resource (CPU/memory) usage
  cordon        Mark node as unschedulable
  uncordon      Mark node as schedulable
  drain         Drain node in preparation for maintenance
  taint         Update the taints on one or more nodes

Troubleshooting and Debugging Commands:
  describe      Show details of a specific resource or group of resources
  logs          Print the logs for a container in a pod
  attach        Attach to a running container
  exec          Execute a command in a container
  port-forward  Forward one or more local ports to a pod
  proxy         Run a proxy to the Kubernetes API server
  cp            Copy files and directories to and from containers
  auth          Inspect authorization
  debug         Create debugging sessions for troubleshooting workloads and nodes

Advanced Commands:
  diff          Diff the live version against a would-be applied version
  apply         Apply a configuration to a resource by file name or stdin
  patch         Update fields of a resource
  replace       Replace a resource by file name or stdin
  wait          Experimental: Wait for a specific condition on one or many resources
  kustomize     Build a kustomization target from a directory or URL.

Settings Commands:
  label         Update the labels on a resource
  annotate      Update the annotations on a resource
  completion    Output shell completion code for the specified shell (bash or zsh)

Other Commands:
  api-resources Print the supported API resources on the server
  api-versions  Print the supported API versions on the server, in the form of "group/version"
  config        Modify kubeconfig files
  plugin        Provides utilities for interacting with plugins
  version       Print the client and server version information

Usage:
  kubectl [flags] [options]

Use "kubectl <command> --help" for more information about a given command.
Use "kubectl options" for a list of global command-line options (applies to all commands).
```

> 这里面有集群帮助有apiversion帮助

### 此时我们想知道有哪些apiversion就可以

```
# kubectl api-versions
admissionregistration.k8s.io/v1
apiextensions.k8s.io/v1
apiregistration.k8s.io/v1
apps/v1
authentication.k8s.io/v1
authorization.k8s.io/v1
autoscaling/v1
autoscaling/v2beta1
autoscaling/v2beta2
batch/v1
batch/v1beta1
certificates.k8s.io/v1
coordination.k8s.io/v1
discovery.k8s.io/v1
discovery.k8s.io/v1beta1
events.k8s.io/v1
events.k8s.io/v1beta1
extensions.istio.io/v1alpha1
flavor.kubevirt.io/v1alpha1
flowcontrol.apiserver.k8s.io/v1beta1
install.istio.io/v1alpha1
k8s.cni.cncf.io/v1
kubevirt.io/v1
kubevirt.io/v1alpha3
metrics.k8s.io/v1beta1
networking.istio.io/v1alpha3
networking.istio.io/v1beta1
networking.k8s.io/v1
node.k8s.io/v1
node.k8s.io/v1beta1
policy/v1
policy/v1beta1
rbac.authorization.k8s.io/v1
scheduling.k8s.io/v1
security.istio.io/v1beta1
snapshot.kubevirt.io/v1alpha1
storage.k8s.io/v1
storage.k8s.io/v1beta1
subresources.kubevirt.io/v1
subresources.kubevirt.io/v1alpha3
telemetry.istio.io/v1alpha1
v1
来获取所有的version版本
```

### 再比如，想要获取api 资源帮助

```
# kubectl api-resources 
....
```

# explain

> 编写yaml神器，有他在任何东西都不是问题

```shell
当我们想要写一个pod的yaml时
# kubectl explain pod
KIND:     Pod
VERSION:  v1

DESCRIPTION:
     Pod is a collection of containers that can run on a host. This resource is
     created by clients and scheduled onto hosts.

FIELDS:
   apiVersion   <string>
     APIVersion defines the versioned schema of this representation of an
     object. Servers should convert recognized schemas to the latest internal
     value, and may reject unrecognized values. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#resources

   kind <string>
     Kind is a string value representing the REST resource this object
     represents. Servers may infer this from the endpoint the client submits
     requests to. Cannot be updated. In CamelCase. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#types-kinds

   metadata     <Object>
     Standard object's metadata. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#metadata

   spec <Object>
     Specification of the desired behavior of the pod. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status

   status       <Object>
     Most recently observed status of the pod. This data may not be up to date.
     Populated by the system. Read-only. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status
```

> 通过这个帮助我们大体知道在yaml中需要指定 kind 和 apiVersion 还有 metadata （元数据） 以及spec

### 不同api版本的 explain yaml

```shell
# 可以通过加上一个 --api-version = ?来指定不同版本的apiversion的资源yaml
例如：
# kubectl explain hpa.spec
KIND:     HorizontalPodAutoscaler
VERSION:  autoscaling/v1

RESOURCE: spec <Object>

DESCRIPTION:
     behaviour of autoscaler. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.

     specification of a horizontal pod autoscaler.

FIELDS:
   maxReplicas  <integer> -required-
     upper limit for the number of pods that can be set by the autoscaler;
     cannot be smaller than MinReplicas.

   minReplicas  <integer>
     minReplicas is the lower limit for the number of replicas to which the
     autoscaler can scale down. It defaults to 1 pod. minReplicas is allowed to
     be 0 if the alpha feature gate HPAScaleToZero is enabled and at least one
     Object or External metric is configured. Scaling is active as long as at
     least one metric value is available.

   scaleTargetRef       <Object> -required-
     reference to scaled resource; horizontal pod autoscaler will learn the
     current resource consumption and will set the desired number of pods by
     using its Scale subresource.

   targetCPUUtilizationPercentage       <integer>
     target average CPU utilization (represented as a percentage of requested
     CPU) over all the pods; if not specified the default autoscaling policy
     will be used.
     

# kubectl explain --api-version=autoscaling/v2beta2 hpa.spec
KIND:     HorizontalPodAutoscaler
VERSION:  autoscaling/v2beta2

RESOURCE: spec <Object>

DESCRIPTION:
     spec is the specification for the behaviour of the autoscaler. More info:
     https://git.k8s.io/community/contributors/devel/sig-architecture/api-conventions.md#spec-and-status.

     HorizontalPodAutoscalerSpec describes the desired functionality of the
     HorizontalPodAutoscaler.

FIELDS:
   behavior     <Object>
     behavior configures the scaling behavior of the target in both Up and Down
     directions (scaleUp and scaleDown fields respectively). If not set, the
     default HPAScalingRules for scale up and scale down are used.

   maxReplicas  <integer> -required-
     maxReplicas is the upper limit for the number of replicas to which the
     autoscaler can scale up. It cannot be less that minReplicas.

   metrics      <[]Object>
     metrics contains the specifications for which to use to calculate the
     desired replica count (the maximum replica count across all metrics will be
     used). The desired replica count is calculated multiplying the ratio
     between the target value and the current value by the current number of
     pods. Ergo, metrics used must decrease as the pod count is increased, and
     vice-versa. See the individual metric source types for more information
     about how each type of metric must respond. If not set, the default metric
     will be set to 80% average CPU utilization.

   minReplicas  <integer>
     minReplicas is the lower limit for the number of replicas to which the
     autoscaler can scale down. It defaults to 1 pod. minReplicas is allowed to
     be 0 if the alpha feature gate HPAScaleToZero is enabled and at least one
     Object or External metric is configured. Scaling is active as long as at
     least one metric value is available.

   scaleTargetRef       <Object> -required-
     scaleTargetRef points to the target resource to scale, and is used to the
     pods for which metrics should be collected, as well as to actually change
     the replica count.
```

> 上述的两个版本中最大不同在于是否可以定义behavior ，这里面有包含时间窗口函数，用来定义事件进入下一步的不同操作

