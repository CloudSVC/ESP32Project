---
title: 企业级运维Ansible，适用于多节点多任务
date: 2023-03-05 21:03:51
tags:
  - 自动化运维
  - Ansible
  - 解决企业运维难的问题
category:
  - 运维
mathjax: true
---
# Ansible

## 概述

**自动化运维的优势**

- **传统的方法**

  > 一台连着一台服务器配置手动或操作

  - **缺点**
    - 效率太低

- **写个shell脚本做**

  - **缺点**
    - 管理的机器平台不一致，脚本可能不同
    - 传密码麻烦
    - 效率较低，循环1000次也需要一个一个的完成

- **自动化运维**
  
  - 简化日常IT运维中大量的重复性工作

## 开始使用Ansible

> #### **主要适用场景**

- **管理机与被管理机的连接**
- **服务器信息收集**
- **服务器分组**
- **管理内容的主要分类**
  - **文件目录管理**
  - **用户和组管理**
  - **chrony时间任务管理**
  - **yum配置与yum管理软件包**
  - **服务管理**
  - **远程执行脚本**
  - **远程执行命令**

> #### **常见的开源自动化运维工具**

- **puppet**
  - **基于ruby语言，适用于大型架构相较于后两位比较复杂**
- **saltstack**
  - **基于python语言，相对简单，但是如果服务器断开连接，连接就会出现问题**
- *** ansible**
  - **基于python语言，相对简单，被管理端不需要启动服务，直接走ssh协议**

### 安装

> **第一步：在管理机上安装ansible**

```shell
# yum -y install epel-release
EPEL (Extra Packages for Enterprise Linux)是基于Fedora的一个项目，为“红帽系”的操作系统提供额外的软件包，适用于RHEL、CentOS和Scientific Linux.
我们在Centos下使用yum安装时往往找不到rpm的情况，官方的rpm repository提供的rpm包也不够丰富，很多时候需要自己编译很痛苦，而EPEL恰恰可以解决这两方面的问题。EPEL的全称叫 Extra Packages for Enterprise Linux 。EPEL是由 Fedora 社区打造，为 RHEL 及衍生发行版如 CentOS、Scientific Linux 等提供高质量软件包的项目。装上了 EPEL之后，就相当于添加了一个第三方源。
```

```shell
# yum -y install epel-release
# yum -y install ansible
# ansible --version
ansible 2.6.14
  config file = /etc/ansible/ansible.cfg
  configured module search path = [u'/root/.ansible/plugins/modules', u'/usr/share/ansible/plugins/modules']
  ansible python module location = /usr/lib/python2.7/site-packages/ansible
  executable location = /usr/bin/ansible
  python version = 2.7.5 (default, Apr 11 2018, 07:36:10) [GCC 4.8.5 20150623 (Red Hat 4.8.5-28)]
```

> **第二步：实现免密登入**

```shell
master# ssh-keygen

master# ssh-copy-id -i /root/.ssh/id_rsa.pub root@110.0.0.20
master# ssh-copy-id -i /root/.ssh/id_rsa.pub root@110.0.0.30
```

> **第三步：定义组**

```shell
# 主配置文件
/etc/ansible/ansible.cfg
在文件中，可以找到清单inventory的位置


# ansible的hosts
/etc/ansible/hosts
在该文件中添加新的组
cat >> /etc/ansible/hosts << EOF
> [node]
> 110.0.0.20
> 110.0.0.30
> EOF
    [node]
    110.0.0.20
    110.0.0.30
# ansible all -m ping 
	all； 配置文件里所配置所有人
	-m：  module调用ping模块，但是它不是ping，类似ssh
110.0.0.30 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
110.0.0.20 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
```

### 服务器分组（主机清单）

> **分组是为了只针对对应的组进行操作，而不操作所有**

```
在/etc/ansible/hosts文件中可以对服务器进行分组操作
[master]
110.0.0.10

[node]
110.0.0.20
110.0.0.30
如上，我们就分出了两个组别

同样的，我们可以通过[99:101]这一个来设置多台ip进入ansible
[mysql]
110.0.0.[16:160]
则设置了16到160的ip地址服务

> 也可以设置端口{针对ssh修改了端口的}
[nginx]
110.0.0.40:2222
```

```
# 如果没有设置免密，同时对方也修改了ssh服务端口号
nginx1 ansible_ssh_host=110.0.0.40 ansible_ssh_port=2222 ansible_ssh_user=root ansible_ssh_pass="000000"

[nginx]
110.0.0.50
nginx1
```

### ansible模块

> **概述**

```
ansible是基于模块工作的，本身没有批量部署的能力。真正具有批量部署的是ansible所运行的模块，ansible只是提供一种框架。
ansible所支持的模块非常多，我们不需要把所有的模块都记住，只需要掌握最常用的模块即可。
```

> **查询所有模块**

```
# ansible-doc -l
a10_server                                           Manage A10 Networks AX/SoftAX/Thunder/vThunder devices' server...
a10_server_axapi3                                    Manage A10 Networks AX/SoftAX/Thunder/vThunder devices
a10_service_group                                    Manage A10 Networks AX/SoftAX/Thunder/vThunder devices' servic...
a10_virtual_server                                   Manage A10 Networks AX/SoftAX/Thunder/vThunder devices' virtua...
accelerate                                           Enable accelerated mode on remote node
aci_aaa_user                                         Manage AAA users (aaa:User)
......
篇幅有限，略
官方文档地址：https://docs.ansible.com/ansible/latest/plugins/module.html

查看指定模块的详细用法：
# ansible-doc group
```

#### 常用模块

##### hostname

```shell
用于修改主机名
# ansible 110.0.0.20 -m hostname -a "name=agent1.com"

-m：  module调用hostname模块修改主机名
-a：  参数，格式"参数1=值1 参数2=值2 参数3=值3"

注意：本模块不能修改/etc/hosts文件
```

##### file

```shell
用于对文件进行相关操作（创建、删除、软硬链接等）
# ansible node -m file -a "path=/tmp/111 state=touch"
# ansible node -m file -a "path=/tmp/aaa/bbb state=directory mode=777"

file -a参数：
	path	路径
	group	组
	mode	权限
	state   如果文件不存在则创建（touch）
```

##### * shell

```shell
用于执行命令
# ansible 110.0.0.20 -m shell -a "ip a"

也可以不需要指定模块（不推荐）
# ansible 110.0.0.20 -a "ip a"
```

##### * script

```shell
在远程机上执行脚本
# ansible node -m script -a "/init.sh"

如何在mysql里面执行(脚本里面写法)
mysql << EOF
create database abc;
quit
EOF

同级目录下有init.sh脚本文件
```

##### copy

```shell
用于复制文件
# ansible node -m copy -a "src=/etc/hosts dest=/etc/hosts"

src：	本地地址（master节点）
dest：	目标地址

通过判断文件的哈希值来判断文件是否被做了修改，如果哈希值一样则视为两个文件一模一样，则不会触发复制这个操作。

```

##### template

```shell
用于模板复制文件
# ansible node -m template -a "src=/root/anisble/ip.yml.j2 dest=/home/test/ip.yml"
[ip.yml.j2]
this is {{ ansible_all_ipv4_addresses[0] }}
这里是一个错误，如果命令行的话不能使用setup的参数，我们需要使用剧本才可以使用setup的参数
[ip.yml.j2]
ip is {{  ansible_all_ipv4_addresses[0]  }}
```

##### stat、fetch、template

```shell
* stat
用于查看文件信息
# ansible node -m stat -a "path=/etc/fstab"

* fetch
与copy类似，但是作用相反，是从远程机器把文件拷贝到本地
# ansible node -m fetch -a "src=/etc/hosts dest=/etc/hosts"
如果目标文件名称相同，则会将在文件添加ip

* template（鸡肋）
与copy模块功能几乎一样
copy可以拷贝目录，template不能拷贝目录
```

##### user

```shell
用于管理用户账户和用户属性
# ansible node -m user -a "name=aaa uid=2000 home=/home/xx shell=/bin/false comment=@_@"

name：	指定用户名
comment：注释
home：	家目录

删除用户并移除家目录
# ansible node -m user -a "name=aaa state=absent remove=yes"
```

##### group、cron

```shell
组创建，只有创建了组用户才能加入group，不存在则无法加入
# ansible node -m group -a "name=aaa group=5000"
如果有用户则无法删除组
# ansible node -m group -a "name=aaa state=absent"

用于管理时间
cron
```

### playbook yaml编写

#### 格式

```
--- 开头结尾进行分割
空格缩进，千万不要用tab
冒号: 后面也要空格
#注释
```

#### 实例

```yaml
# 指定组
- hosts: node
# 指定用户
  remote_user: root
# 指定任务
  tasks:
  # 任务说明，可以写中文
  - name: 安装httpd
  # 调用的模块和模块的参数
    yum: name=httpd,httpd-devel state=present

  - name: 复制配置文件
    copy: src=/root/ansible/httpd.conf dest=/etc/httpd/conf/httpd.conf
    # 当配置文件发生改变时，调用restart apache这个处理
    notify:
    - restart apache

  - name: 启动服务
    service: name=httpd state=started enabled=yes
  # 指定处理
  handlers:
    - name: restart apache
      service: name=httpd state=restarted

执行剧本（playbook）
# ansible-playbook /root/anible/playbook/example.yml

同级目录下有example.yml,httpd.conf文件
```

### playBook中使用变量

```
调用变量 {{ 变量名称 }}

定义变量的方法；
	1. 在playbook中定义vars的值：
		vars: 
		- username: "userA"
	2. 在主机清单中定义变量：
		1) 每个主机定义不同的变量：
			192.168.100.100 username="userB"
		2) 主机组定义变量：
			[主机组名:vars]
			- username="userC"
```

### playBook中使用条件判断

```
when === if

tasks:
- name: install bind
  yum: 
  - name: bind
    state: present
  when: ansible_nodename="node1"
  (这里使用anisble唯一标识主机来判断)
  
- name: install dhcp
  yum: 
  - name: dhcp
    state: present
  when: ansible_nodename="node2"
  (这里使用anisble唯一标识主机来判断)

如何查看ansible唯一标识？
ansible node -m setup
```

### handlers

```
默认不执行，只有满足某些条件才会执行
应用于配置文件修改时，服务重启
tasks:
- name: copy httpd.conf
  copy: src=/etc/httpd/conf/httpd.conf dest=/etc/httpd/conf/httpd.conf
  notify: restart httpd

handlers: 
- name: restart httpd
  service: name=httpd state=restarted
```

### template模块

```
只能用于playbook中
用于配置文件模板实现变量替换
建议准备jinja配置文件时，文件名以.j2为结尾。以区分普通文件

[ip.yml.j2]
ip is {{ ansible_all_ipv4_addresses[0] }}

在剧本中不能使用copy来传递文件了，而是使用模板
[playbook.yml]
- hosts: node
  remote_user: root
  tasks:
  - name: copy file
    template: src=/root/ansible/playbook/ip.yml.j2 dest=/ip.yml
```

### lineinfile模块

```
playbook写法：
lineinfile:
    path: /root/config
    regexp: '^SELINUX='
    line: '此行已被我替换了'

命令行写法：
ansible node -m lineinfile -a "path=/root/config regexp='^SELINUX=' line='已被替换'"
```

# Prometheus

## 服务端配置文件写法

```
scrape_interval: 15s  # 抓取数据的间隔
······················
- job_name: "prometheus"
  static_configs:
  - targets: ["server1:9100","server2:9100"]

node_exporter的默认运行端口9100
```

### 安装node_exporter

```
解压，然后运行即可
安装完成node_exporter后需要进行检查，以便检测node_exporter是否正常运行
curl localhost:9100
<html>
<head><title>Node Exporter</title></head>
<body>
<h1>Node Exporter</h1>
<p><a href="/metrics">Metrics</a></p>
</body>
</html>

会抓取监控数据，自动暴露9100端口
```

# 对不同主机设置不同的变量

```
# 在hosts文件中我们可以设置主机变量
# 例如：
node1 ansible_ssh_host=172.18.10.10 ansible_ssh_user=root
node2 ansible_ssh_host=172.18.10.20 ansible_ssh_user=root

[controller]
node1 zk_id=10

[compute]
node2 zk_id=20

# 这时我们通过剧本即可调用这些变量例如：
- hosts: all
  remote_user: root
  tasks:
  - name: 测试
    shell: echo {{ zk_id }} >> /root/hellozk.txt

# 这里我们的变量就会被写入到hellozk这个文件当中
```

