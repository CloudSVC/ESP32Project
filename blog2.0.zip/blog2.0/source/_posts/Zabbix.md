---
title: Zabbix
date: 2023-03-24 15:57:51
tags:
  - 自动化管理
  - Zabbix
  - 理论
category:
  - 运维
mathjax: true
---
# Zabbix

## 安装

> - zabbix-*
> - mariadb && mariadb-server
> - httpd

```
# 执行这步之前请确认你是否有zabbix的yum源
yum -y install zabbix-* mariadb mariadb-server httpd

# 如果没有yum源则优先做如下配置
cd /opt/
tar -zxvf zabbix.tar.gz
vi /etc/yum.repos.d/zabbix.repo
[zabbix]
name=zabbix
baseurl=file:///opt/zabbix/
gpgcheck=0
enabled=1
yum clean all && yum repolist
```

## 创建数据库zabbix并赋权user

```
# 初始化数据库
mysql_install_db --user=mysql
systemctl enable mariadb --now

# 设置root密码
mysqladmin -uroot password root

# 连接数据库
mysql -uroot -proot 

# 创建zabbix数据库
mysql > create database zabbix;

# 创建用户zabbix并设置密码
mysql > CREATE USER 'zabbix'@'localhost' IDENTIFIED BY 'zabbix';

# 赋权
mysql > GRANT ALL ON zabbix.* TO 'zabbix'@'localhost' IDENTIFIED BY 'zabbix';
```

## 导入数据

> 在本地中有一个create.sql的数据，需要导入到我们创建好的zabbix数据库中

```
cd /usr/share/doc/zabbix-server-mysql-3.4.15

# 导入数据
zcat create.sql.gz | mysql -uzabbix -pzabbix zabbix
```

## 修改zabbix_server.conf

> 这个文件是用来配置服务的配置文件，这里面需要修改数据库的密码来保证服务能连接到数据库

```
vi /etc/zabbix/zabbix_server.conf

# 将DBPassword修改为你的数据库密码例如我这里是zabbix
DBPassword=zabbix
```

## 修改timezone

```
需要修改php.ini里面的timezone为Asia/Shanghai

vi /etc/php.ini
date.timezone = Asia/Shanghai
```

## 全部完成后重启服务

```
systemctl restart zabbix-server zabbix-agent httpd
```

> **通过 IP/zabbix 来访问服务**

![](https://user-images.githubusercontent.com/93499895/226099143-c0895a67-7358-4f1f-89de-126fe8a44340.png)

## 添加另一个节点到zabbix服务

> 在节点上安装 zabbix-agent 服务

```
yum -y install zabbix-agent
```

> 修改配置文件 /etc/zabbix/zabbix_agentd.conf

```
vi /etc/zabbix/zabbix_agentd.conf

Server=127.0.0.1
修改为
Server=172.18.10.20

改完后重启服务即可
systemctl restart zabbix-agent
```

