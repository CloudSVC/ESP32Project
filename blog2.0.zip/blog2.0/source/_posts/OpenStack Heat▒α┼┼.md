---
title: OpenStack Heat 编排
date: 2023-03-07 16:04:51
tags:
  - 私有云
  - 编排
  - 企业级应用
category: 
  - 运维
mathjax: true
---
# OpenStack Heat编排

> 通过heat快捷创建资源，调用API

![](https://user-images.githubusercontent.com/93499895/218908304-72804985-6bd7-48eb-bb61-e812f68af2c1.png)

> 常用案例 例如，要开几台虚拟机，里面装什么服务等

![](https://user-images.githubusercontent.com/93499895/218909058-7adca865-de29-405f-8ab7-0087d420e471.png)

> 在这里heat不直接接触资源而是通过别的服务的API去操作服务

## Template

> 模板可以多次创建资源，使用YAML格式编写

### 格式

```
# 指定版本
heat_template_version:2016-10-14
# 描述，可选
description:
# 输入参数组和输入顺序， 可选
parameter_groups:
# 输入参数，可选
parameters:
# 需要用到的资源，例如计算、存储、网络等
resources:
# 输出参数，可选
outputs:
# 条件，可选
conditions:
```

### dashboard 可以查看模板属性

> 例如cinder 的volume

```
attachments: {description: A string representation of the list of attachments of the
    volume., type: string}
attachments_list: {description: The list of attachments of the volume., type: list}
availability_zone: {description: The availability zone in which the volume is located.,
  type: string}
bootable: {description: Boolean indicating if the volume can be booted or not., type: string}
created_at: {description: The timestamp indicating volume creation., type: string}
display_description: {description: Description of the volume., type: string}
display_name: {description: Name of the volume., type: string}
encrypted: {description: Boolean indicating if the volume is encrypted or not., type: string}
metadata: {description: Key/value pairs associated with the volume., type: string}
metadata_values: {description: Key/value pairs associated with the volume in raw dict
    form., type: map}
multiattach: {description: Boolean indicating whether allow the volume to be attached
    more than once., type: boolean}
show: {description: Detailed information about resource., type: map}
size: {description: The size of the volume in GB., type: string}
snapshot_id: {description: 'The snapshot the volume was created from, if any.', type: string}
source_volid: {description: 'The volume used as source, if any.', type: string}
status: {description: The current status of the volume., type: string}
volume_type: {description: 'The type of the volume mapping to a backend, if any.',
  type: string}

```

### 命令行查看支持的类型列表

```
openstack orchestration resource type list
```

> 如果需要查看某个具体类型的详细信息可以使用

```
openstack orchestration resource type show OS::Nova::Server
```

### 创建一个swift容器

```
vi container.yaml

heat_template_version: 2018-03-02
description: "create a container"
resources:
  test:
    type: OS::Swift::Container
    properties:
      PurgeOnDelete: true
      name: test
```

> 执行创建

```
openstack stack create -t container.yaml swift
```

## 上真题

> 在提供的OpenStack平台上，编写heat模板createnet.yml文件，模板作用为按照要求创建一个网络和子网。

```
vi createnet.yaml

heat_template_version: 2018-03-02
description: "create a net and subnet"
resources:
  test-net:
    type: OS::Neutron::Net
    properties:
      name: test-net
  test-subnet:
    type: OS::Neutron::Subnet
    properties:
      allocation_pools: 
      - start: 192.168.100.101
        end: 192.168.100.201
      cidr: 192.168.100.0/24
      gateway_ip: 192.168.100.1
      network: {get_resource: test-net}
      name: test-subnet
```



