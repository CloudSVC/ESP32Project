---
title: MySQL的一些基操
date: 2023-03-05 20:35:51
tags:
  - MySQL
  - 运维入门
category:
  - 运维
mathjax: true
---
# MySQL基本操作

## 基本操作命令及逻辑

> **查询并创建数据库**

```
# 查询数据库
show databases;

# 创建数据库
create database taobao;

# 进入or使用数据库
use taobao;
```

> **查询并创建数据表结构**

```
# 查询所有数据表
show tables;

# 创建数据表
create table shop(commodity int,commodity2 int,commodity3 varchar(30));
```

> **数据写入擦除**

```
# 写入数据
insert into shop value(123,123,'hello world');

# 查询是否写入数据
select * from shop;

# 修改数据
update shop set commodity=456;
## 限定修改某一行数据
update shop set commodity2=789 where commodity=123;
```

> **移除数据、数据表和数据库**

```
# 删除某行数据，限定删除某一行数据
delete from shop where commodity=123;

# 删除数据表
drop table shop;

# 删除数据库
drop database taobao;
```

> 熟练使用help

```
通过help来查看帮助
例如赋权可以查看 help grant; < 也可以查看系统自带的一些已经赋权的用户 show grants for nuanyang;
创建用户可以查看 help create user;
```

> 查看MySQL密码的哈希值，用于设置密码用

```
MariaDB [mysql]> select password('123456');
```

## Mysql区分大小写(大小写敏感)配置

```
mysql > show variables;
通过show variables 我们可以查看系统的变量

比如我们要查看区分大小写 我们只知道前面是lower不知道后面咋办？？？
可以通过
mysql > show variables like 'lower%';
通过这个命令我们可以找到所有以lower开头的，从而找到我们所需要的系统变量
```

> 跳过主从复制错误：slave_skip_errors=1062
