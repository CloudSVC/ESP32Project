---
title: Tkinter
date: 2023-03-08 20:30:51
tags:
  - Python
  - UI开发
  - 理论
category:
  - 开发
mathjax: true
---
# Python图形化开发(tkinter)

## ttkbootstrap界面美化

```
GitHub地址：https://github.com/israel-dryer/ttkbootstrap
```

## 开始（tkinter)

### 案例1

```python
# 默认就有tkinter了
import tkinter as tk
# 实例化一个对象
app = tk.Tk()
# 设置大小500 * 300 距离屏幕右上角 100 * 100
app.geometry('500x300+100+100')
# 设置窗体头文字
app.title('hello world')

# 显示窗体
app.mainloop()
```

### 案例2

```python
import tkinter as tk
from tkinter import messagebox

app = tk.Tk()
app.geometry('500x300+100+100')
app.title('hello world')

# 创建页面1
frame1 = tk.Frame(app)
# frame1.pack()

# 设置内容标语
# Label设置在那个窗体，内容是什么，字体大小，边距
# pack将东西进行展示，并设置它在左右哪里（LEFT,RIGHT），上下的位置（N,S）
tk.Label(frame1, text='Hello World!!', font=14, padx=10, pady=10).pack(side=tk.LEFT, anchor=tk.N)

# 导入图片
img = tk.PhotoImage(file='D:/桌面壁纸/15.png')
tk.Label(frame1, image=img, padx=30, pady=30, bd=0).pack(side=tk.LEFT, anchor=tk.N)

# 设置按钮
btn = tk.Button(frame1, text='yes', bd=0, height=10, width=30)
btn.place(relx=0.3, rely=0.7, anchor=tk.S)


# 创建页面2
frame2 = tk.Frame(app)
frame2.pack()
# 设置一个窗体，字体，高度，颜色
tk.Label(frame2,
         text='再见，再也不见\n嘿嘿，有缘再来\nbyebye',
         font=('楷体', 40),
         height=300,
         fg='red',
         ).pack()
# 创建一个按钮，并设置命令，使其能退出界面
tk.Button(frame2, text='退出',command=app.quit).place(relx=0.9,rely=0.8)

# 让用户无法自己退出页面
## 定义一个函数，调用时提示信息
def on_exit():
    messagebox.showwarning(title='提示', message='此路不通')
## 当点击退出时，调用函数
app.protocol('WM_DELETE_WINDOW', on_exit)

# 使用按钮来转变窗体
def change():
	# 将第一个窗体隐藏
    frame1.pack_forget()
    # 将第二个窗体展示
    frame2.pack()
btn.config(command=change)

app.mainloop()

```

### 案例3

```python
# 本案例设计菜单的设计
import tkinter as tk

app = tk.Tk()
app.title('记事本')
app.geometry('500x500+100+100')

# 创建一个总目录，用于存放一级功能
menu = tk.Menu(app, tearoff=False)

# 创建一个子目录，用于存放具体功能
file_menu = tk.Menu(menu, tearoff=False)
## 创建每个子功能
file_menu.add_command(label='新建')
file_menu.add_command(label='打开')
file_menu.add_command(label='保存')
file_menu.add_command(label='另存为')

# 创建一个子目录，用于存放具体功能
edit_menu = tk.Menu(menu, tearoff=False)
## 创建每个子功能
edit_menu.add_command(label='撤销')
edit_menu.add_command(label='重做')
## 添加一条分割线
edit_menu.add_separator()
edit_menu.add_command(label='复制')
edit_menu.add_command(label='粘贴')
edit_menu.add_command(label='剪切')

# 将子目录放入总目录中，并修改名称
menu.add_cascade(label='文件', menu=file_menu)
menu.add_cascade(label='编辑', menu=edit_menu)

# 创建底部状态栏
# 定义一个可以跟踪变量值的变化
status_str = tk.StringVar()
status_str.set('字符数：{}'.format(0))
status_label = tk.Label(app, textvariable=status_str, bd=1, relief=tk.SUNKEN, anchor=tk.W)
status_label.pack(side=tk.BOTTOM, fill=tk.X)

# 文本对象
text_pad = tk.Text(app, font=18)
text_pad.pack(fill=tk.BOTH, expand=True)

# 滚动条
scroll = tk.Scrollbar(text_pad)
# 让滚动条随着文本增加和变长
text_pad.config(yscrollcommand=scroll.set)
# 让滚动条可以控制文本的位置
scroll.config(command=text_pad.yview)
# side定位，fill顶满
scroll.pack(side=tk.RIGHT, fill=tk.Y)

app.config(menu=menu)
app.mainloop()
```

### 案例4.1

```python
import tkinter as tk
from tkinter import messagebox

app = tk.Tk()
app.title('计算器')
app.geometry('295x300+100+100')
# 设置透明化效果
app.attributes('-alpha',0.9)
# 设置背景颜色
app['background'] = '#FFF'



def hello():
    messagebox.showinfo(title='提示', message='你好')


def on_exit():
    app.quit()

# 创建目录
menu = tk.Menu(app, tearoff=False)

clear_menu = tk.Menu(menu, tearoff=False)
clear_menu.add_command(label='清除', command=hello)
clear_menu.add_command(label='重做')
clear_menu.add_command(label='退出', command=on_exit)
clear_menu.add_separator()
clear_menu.add_command(label='关于')
menu.add_cascade(label='功能', menu=clear_menu)

# 定义一个可以跟踪变量值的变化
resule_num = tk.StringVar()
resule_num.set(0)
font = ('宋体', 18)
tk.Label(app,
         textvariable=resule_num, height=2,
         width=23, justify=tk.LEFT, anchor=tk.SE,
         font=font).grid(row=1, column=1, columnspan=4)

btn_clear = tk.Button(app, text='C', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT)
btn_add = tk.Button(app, text='→', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT)
btn_del = tk.Button(app, text='/', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT)
btn_xx = tk.Button(app, text='x', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT)
btn_clear.grid(row=2, column=1, padx=2, pady=2)
btn_add.grid(row=2, column=2, padx=2, pady=2)
btn_del.grid(row=2, column=3, padx=2, pady=2)
btn_xx.grid(row=2, column=4, padx=2, pady=4)


btn_seven = tk.Button(app, text='7', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_eight = tk.Button(app, text='8', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_nine = tk.Button(app, text='9', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_delete = tk.Button(app, text='-', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT)
btn_seven.grid(row=3, column=1, padx=2, pady=2)
btn_eight.grid(row=3, column=2, padx=2, pady=2)
btn_nine.grid(row=3, column=3, padx=2, pady=2)
btn_delete.grid(row=3, column=4, padx=2, pady=4)

btn_four = tk.Button(app, text='4', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_five = tk.Button(app, text='5', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_six = tk.Button(app, text='6', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_add = tk.Button(app, text='+', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT)
btn_four.grid(row=4, column=1, padx=2, pady=2)
btn_five.grid(row=4, column=2, padx=2, pady=2)
btn_six.grid(row=4, column=3, padx=2, pady=2)
btn_add.grid(row=4, column=4, padx=2, pady=4)

btn_one = tk.Button(app, text='1', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_two = tk.Button(app, text='2', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_three = tk.Button(app, text='3', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_deng = tk.Button(app, text='=', width=5, font=font, bg='#b1b2b2', relief=tk.FLAT, height=3)
btn_one.grid(row=5, column=1, padx=2, pady=2)
btn_two.grid(row=5, column=2, padx=2, pady=2)
btn_three.grid(row=5, column=3, padx=2, pady=2)
btn_deng.grid(row=5, column=4, padx=2, pady=4, rowspan=2)

btn_zero = tk.Button(app, text='0', width=12, font=font, bg='#eacda1', relief=tk.FLAT)
btn_dot = tk.Button(app, text='.', width=5, font=font, bg='#eacda1', relief=tk.FLAT)
btn_zero.grid(row=6, column=1, padx=2, pady=2, columnspan=2)
btn_dot.grid(row=6, column=3, padx=2, pady=2)


app.config(menu=menu)
app.mainloop()
```

### 案例4.2

```python
def clean():
    resule_num.set('')

# 计算器逻辑编写
# 设置事件
def click(x):
    resule_num.set(resule_num.get() + x)


def deng():
    result = eval(resule_num.get())
    resule_num.set(str(result))


btn_one.config(command=lambda: click('1'))
btn_two.config(command=lambda: click('2'))
btn_three.config(command=lambda: click('3'))
btn_four.config(command=lambda: click('4'))
btn_five.config(command=lambda: click('5'))
btn_six.config(command=lambda: click('6'))
btn_seven.config(command=lambda: click('7'))
btn_eight.config(command=lambda: click('8'))
btn_nine.config(command=lambda: click('9'))
btn_zero.config(command=lambda: click('0'))
btn_add.config(command=lambda: click('+'))
btn_delete.config(command=lambda: click('-'))
btn_xx.config(command=lambda: click('*'))
btn_del.config(command=lambda: click('/'))
btn_dot.config(command=lambda: click('.'))
btn_clear.config(command=lambda: clean())

btn_deng.config(command=lambda: deng())
```

### 案例5

```python
# 网络调试工具布局
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox

app = tk.Tk()
app.title('网络调试工具')
app.geometry('650x500+100+100')


def message():
    messagebox.showinfo(title='提示', message='Version:1.0\nDate:2022-6-25')


# 目录
menu = tk.Menu(app, tearoff=False)
file_menu = tk.Menu(menu, tearoff=False)
file_menu.add_command(label='关于', command=lambda: message())
menu.add_cascade(label='操作', menu=file_menu)
app.config(menu=menu)

'''左边布局'''
left_frame = tk.Frame(app)
left_frame.pack(side=tk.LEFT, anchor=tk.N, padx=5, pady=5)

'''左边布局 网络设置'''
net_frame = tk.LabelFrame(left_frame, text='网络设置', padx=5, pady=5)
net_frame.pack()

tk.Label(net_frame, text='(1)协议类型').pack(anchor=tk.W)
# 构建一个可以下拉的选项体
socket_type = ttk.Combobox(net_frame)
socket_type['values'] = ['TCP服务器', 'TCP客户端']
# 设置默认为第一个
socket_type.current(0)
socket_type.pack(anchor=tk.W)

tk.Label(net_frame, text='(2)本地主机地址').pack(anchor=tk.W)
# 构建一个可以下拉的选项体
socket_host = ttk.Combobox(net_frame)
socket_host['values'] = ['127.0.0.1', '192.168.0.1']
# 设置默认为第一个
socket_host.current(0)
socket_host.pack(anchor=tk.W)

tk.Label(net_frame, text='(3)本地端口').pack(anchor=tk.W)
# 构建一个可以输入
entry_port = ttk.Entry(net_frame)
entry_port.pack(fill=tk.X)

# 按钮嵌套
button_frame = tk.Frame(net_frame)
button_frame.pack()
open_button = tk.Button(button_frame, text='打开')
close_button = tk.Button(button_frame, text='关闭')
open_button.pack(side=tk.LEFT)
close_button.pack(side=tk.RIGHT)


'''左边布局 接收设置'''
recv_frame = tk.LabelFrame(left_frame, text='接收设置', padx=5, pady=5)
recv_frame.pack(side=tk.TOP, anchor=tk.N, fill=tk.X)
# 单选框
radio_var_1 = tk.IntVar()
tk.Radiobutton(recv_frame, text='UTF-8', variable=radio_var_1, value=0).pack(anchor=tk.W)
tk.Radiobutton(recv_frame, text='GBK', variable=radio_var_1, value=1).pack(anchor=tk.W)
# 复选框
radio_var_2 = tk.IntVar()
radio_var_3 = tk.IntVar()
tk.Checkbutton(recv_frame, text='解析为JSON', variable=radio_var_2).pack(anchor=tk.W)
tk.Checkbutton(recv_frame, text='自动换行', variable=radio_var_3).pack(anchor=tk.W)

'''左边布局 发送设置'''
recx_frame = tk.LabelFrame(left_frame, text='发送设置', padx=5, pady=5)
recx_frame.pack(side=tk.TOP, anchor=tk.N, fill=tk.X)
# 单选框
tk.Radiobutton(recx_frame, text='UTF-8').pack(anchor=tk.W)
tk.Radiobutton(recx_frame, text='GBK').pack(anchor=tk.W)
# 复选框
tk.Checkbutton(recx_frame, text='数据加密').pack(anchor=tk.W)
tk.Checkbutton(recx_frame, text='数据接受').pack(anchor=tk.W)


'''右边布局'''
right_frame = tk.Frame(app)
right_frame.pack(side=tk.TOP, anchor=tk.N, padx=5, pady=5)

# 数据日志
info_frame = tk.Frame(right_frame)
info_frame.pack()
tk.Label(info_frame, text='数据日志').pack(anchor=tk.W)

text_pad = tk.Text(info_frame, width=62)
text_pad.pack(side=tk.LEFT, fill=tk.X)

send_text_bar = tk.Scrollbar(info_frame)
send_text_bar.pack(side=tk.RIGHT, fill=tk.Y)
text_pad.config(yscrollcommand=send_text_bar.set)
send_text_bar.config(command=text_pad.yview)

tk.Label(right_frame, text='信息发送').pack(anchor=tk.W)
send_frame = tk.Frame(right_frame)
send_frame.pack()

send_area = tk.Text(send_frame, width=58, height=6)
send_area.pack(side=tk.LEFT)

send_area_button = tk.Button(send_frame, text='发送', width=4)
send_area_button.pack(side=tk.RIGHT, fill=tk.Y)

app.mainloop()
```

### 案例6（学生管理系统）

```python
# 登入页面布局和逻辑
# 通过class封装方便后续进行操作
import tkinter as tk
from tkinter import messagebox
from db import db


class LoginPage:
    def __init__(self, root):
        self.app = root
        self.app.title('登入')
        self.app.geometry('300x180')

        self.username = tk.StringVar()
        self.username.set('张三')
        self.passwd = tk.StringVar()

        self.login_page = tk.Frame(self.app)
        self.login_page.pack()

        tk.Label(self.login_page).grid(row=0, column=0)

        tk.Label(self.login_page, text='账户：').grid(row=1, column=1)
        tk.Entry(self.login_page, textvariable=self.username, width=15).grid(row=1, column=2)

        tk.Label(self.login_page, text='密码：').grid(row=2, column=1)
        tk.Entry(self.login_page, textvariable=self.passwd, width=15).grid(row=2, column=2, pady=15)


        def login():
            name = self.username.get()
            pwd = self.passwd.get()
            check, message = db.check_login(name, pwd)
            if check:
                # 销毁当前的页面
                self.login_page.destroy()
                # 登入管理系统页面
                MainPage(self.app)
            else:
                messagebox.showwarning(title='提示', message=message)

        tk.Button(self.login_page, text='登录', command=login).grid(row=4, column=1, pady=15)
        tk.Button(self.login_page, text='退出', command=self.app.quit).grid(row=4, column=2, pady=15)




if __name__ == '__main__':
    root = tk.Tk()
    LoginPage(root=root)
    root.mainloop()
    
```

```python
# 编写数据模型，封装登入页
# 编写users json用于存储密码
users.json
[
  {"username":  "admin","passwd": "123456"},
  {"username":  "nndty","passwd": "123456"},
  {"username":  "张三","passwd": "123456"},
  {"username":  "laozhang","passwd": "123456"}
]
# 编写对应的检测文件db用于判断数据的准确性
import json


class MysqlDatabase:
    def __init__(self):
        with open('users.json', 'r', encoding='utf-8') as F:
            self.users = json.load(F)
	# 遍历整个数组，用于验证数据的准确性
    def check_login(self, username, passwd):
        # print(self.users[0]['username'])

        for user in self.users:
            if username == user['username']:
                if passwd == user['passwd']:
                    return True, '登入成功'
                else:
                    return False, '密码错误'
        return False, '用户名密码错误'
    
     def search_students(self):
        # 查询英语高于60分的老六
        # for student in self.students:
        #     if student['英语'] > 60:
        #         print(student['name'])
        pass

    def delete_by_name(self, name):
        for stu in self.students:
            if stu['name'] == name:
                self.students.remove(stu)
                return True, '{}用户删除成功'.format(name)
        return False, '{}用户不存在'.format(name)
    
    def change_by_name(self, name):
        for stu in self.students:
            if stu['name'] == name:
                return True, stu
        return False, stu

    def change_delete_by_name(self, name):
        for stu in self.students:
            if stu['name'] == name:
                self.students.remove(stu)


# 测试场地
db = MysqlDatabase()
```

```python
# 主体页面布局
import tkinter as tk
from tkinter import ttk
from db import db

class MainPage:
    def __init__(self, root: tk.Tk):
        self.app = root
        self.change_frame = tk.Frame(self.app)
        self.about_frame = tk.Frame(self.app)
        self.insert_frame = tk.Frame(self.app)
        self.search_frame = tk.Frame(self.app)
        self.delete_frame = tk.Frame(self.app)
        self.app.title('学生信息管理系统')
        self.app.geometry('600x400')
        self.meNu()

    def all_Page(self):
        # 关于页面
        tk.Label(self.about_frame, height=5).grid(row=0, column=1)
        tk.Label(self.about_frame, text='关于作品：使用Python-tkinter制作').grid(row=1, column=1)
        tk.Label(self.about_frame, text='关于作者：暖暖的太阳').grid(row=2, column=1)
        tk.Label(self.about_frame, text='版权所有：©暖暖的太阳').grid(row=3, column=1)
        # 修改页面
        tk.Label(self.change_frame, text='修改页面', height=2).grid(row=0, column=1)
        tk.Label(self.change_frame, text='姓名：').grid(row=1, column=1, pady=15)
        tk.Entry(self.change_frame).grid(row=1, column=2)
        tk.Label(self.change_frame, text='数学：').grid(row=2, column=1, pady=15)
        tk.Entry(self.change_frame).grid(row=2, column=2)
        tk.Label(self.change_frame, text='语文：').grid(row=3, column=1, pady=15)
        tk.Entry(self.change_frame).grid(row=3, column=2)
        tk.Label(self.change_frame, text='英语：').grid(row=4, column=1, pady=15)
        tk.Entry(self.change_frame).grid(row=4, column=2)
        change_button = tk.LabelFrame(self.change_frame, width=135)
        change_button.grid(row=5, column=2, pady=15)
        tk.Button(change_button, text='查询').pack(side=tk.LEFT)
        tk.Button(change_button, text='修改').pack(side=tk.RIGHT)

        # 录入页面
        tk.Label(self.insert_frame, text='录入页面', height=2).grid(row=0, column=1)
        tk.Label(self.insert_frame, text='姓名：').grid(row=1, column=1, pady=15)
        tk.Entry(self.insert_frame, textvariable=self.name).grid(row=1, column=2)
        tk.Label(self.insert_frame, text='数学：').grid(row=2, column=1, pady=15)
        tk.Entry(self.insert_frame, textvariable=self.math).grid(row=2, column=2)
        tk.Label(self.insert_frame, text='语文：').grid(row=3, column=1, pady=15)
        tk.Entry(self.insert_frame, textvariable=self.english).grid(row=3, column=2)
        tk.Label(self.insert_frame, text='英语：').grid(row=4, column=1, pady=15)
        tk.Entry(self.insert_frame, textvariable=self.chinese).grid(row=4, column=2)
        insert_button = tk.LabelFrame(self.insert_frame, width=135)
        insert_button.grid(row=5, column=2, pady=15)
        tk.Button(insert_button, text='录入', command=lambda: self.recode_info()).pack(side=tk.LEFT)
        tk.Button(insert_button, text='清空', command=lambda: self.clean_insert()).pack(side=tk.RIGHT)
        tk.Label(self.insert_frame, textvariable=self.insert_status).grid(row=6, column=2)
        
        # 由于代码过于冗长，在下方有更详细的介绍
        # 查询页面
        # 见下方查询页面的内容
        
        # 删除页面
        # 见下方删除页面的内容
        
        # 修改页面
        # 见下方修改页面的内容

    def meNu(self):

        menu = tk.Menu()
        self.all_Page()
        menu.add_command(label='录入', command=lambda: {self.allPackDown(), self.insert_frame.pack()})
        menu.add_command(label='查询', command=lambda: {self.allPackDown(), self.search_frame.pack()})
        menu.add_command(label='删除', command=lambda: {self.allPackDown(), self.delete_frame.pack()})
        menu.add_command(label='修改', command=lambda: {self.allPackDown(), self.change_frame.pack()})
        menu.add_command(label='关于', command=lambda: {self.allPackDown(), self.about_frame.pack()})
        self.app.config(menu=menu)

    def allPackDown(self):
        self.about_frame.pack_forget()
        self.change_frame.pack_forget()
        self.insert_frame.pack_forget()
        self.search_frame.pack_forget()
        self.delete_frame.pack_forget()
```

```python
# 查询页面数据交互
        # 查询页面
        columns = ('name', 'math', 'chinese', 'english')
        tree_view = ttk.Treeview(self.search_frame, show='headings', columns=columns)
        # 设置每一列对应的名称
        tree_view.column('name', width=80, anchor=tk.CENTER)
        tree_view.column('math', width=80, anchor=tk.CENTER)
        tree_view.column('chinese', width=80, anchor=tk.CENTER)
        tree_view.column('english', width=80, anchor=tk.CENTER)
        # 设置每一列对应展示的名称
        tree_view.heading('name', text='姓名')
        tree_view.heading('math', text='数学')
        tree_view.heading('chinese', text='语文')
        tree_view.heading('english', text='英语')
        # 设置横向和纵向铺满，同时允许扩大
        tree_view.pack(fill=tk.BOTH, expand=True)
        self.showStudentData()
        tk.Button(self.search_frame, text='刷新数据', command=lambda: self.showStudentData()).pack(anchor=tk.E, pady=5)
        
    # 逻辑编写-数据交互
    def showStudentData(self):
        # 删除旧数据
        for _ in map(self.tree_view.delete, self.tree_view.get_children('')):
            pass
        students = db.students
        index = 0
        for stu in students:
            self.tree_view.insert('', index+1, values=(
                stu['name'], stu['数学'], stu['语文'], stu['英语']
            ))

# 录入页面逻辑编写
    def clean_insert(self):
        self.name.set('')
        self.math.set('')
        self.chinese.set('')
        self.english.set('')
        self.insert_status.set('')


    def recode_info(self):
        math_s = float(self.math.get())
        chinese_s = float(self.chinese.get())
        english_s = float(self.english.get())
        stu = {"name":  self.name.get(), "数学":  math_s, "语文":  chinese_s, "英语":  english_s}
        # 将数据录入
        # 尚未做数据持久化存储！！
        db.students.append(stu)
        self.insert_status.set('数据录入成功')
        
# 删除页面以及逻辑编写
		# 删除页面
		tk.Label(self.delete_frame, text='根据姓名删除对应数据').grid(row=0, column=2, pady=15)
        tk.Label(self.delete_frame, text='姓名：').grid(row=1, column=1)
        tk.Entry(self.delete_frame, textvariable=self.delete_name).grid(row=1, column=2)
        tk.Button(self.delete_frame, text='删除', command=lambda: self.delete_student()).grid(row=2, column=2, pady=15)
        tk.Label(self.delete_frame, textvariable=self.delete_status).grid(row=3, column=2)
        
        # 逻辑编写
    def delete_student(self):
        username = self.delete_name.get()
        flag, message = db.delete_by_name(username)
        self.delete_status.set(message)

# 修改页面
		tk.Label(self.change_frame, text='修改页面', height=2).grid(row=0, column=1)
        tk.Label(self.change_frame, text='姓名：').grid(row=1, column=1, pady=15)
        tk.Entry(self.change_frame, textvariable=self.change_name).grid(row=1, column=2)
        tk.Label(self.change_frame, text='数学：').grid(row=2, column=1, pady=15)
        tk.Entry(self.change_frame, textvariable=self.change_math).grid(row=2, column=2)
        tk.Label(self.change_frame, text='语文：').grid(row=3, column=1, pady=15)
        tk.Entry(self.change_frame, textvariable=self.change_chinese).grid(row=3, column=2)
        tk.Label(self.change_frame, text='英语：').grid(row=4, column=1, pady=15)
        tk.Entry(self.change_frame, textvariable=self.change_english).grid(row=4, column=2)
        change_button = tk.LabelFrame(self.change_frame, width=135)
        change_button.grid(row=5, column=2, pady=15)
        tk.Button(change_button, text='查询', command=lambda: self.change_search()).pack(side=tk.LEFT)
        tk.Button(change_button, text='修改', command=lambda: self.change_change()).pack(side=tk.RIGHT)
        tk.Label(self.change_frame, textvariable=self.change_status).grid(row=6, column=2)
        
        
        # 逻辑编写
    def change_change(self):
        math_s = float(self.change_math.get())
        chinese_s = float(self.change_chinese.get())
        english_s = float(self.change_english.get())
        stu = {"name": self.change_name.get(), "数学": math_s, "语文": chinese_s, "英语": english_s}
        db.change_delete_by_name(self.change_name.get())
        db.students.append(stu)
        self.change_status.set('修改成功')
        self.change_name.set('')
        self.change_math.set('')
        self.change_chinese.set('')
        self.change_english.set('')

    def change_search(self):
        name = self.change_name.get()
        flag, students = db.change_by_name(name)
        if flag:
            self.change_status.set('查询成功')
            self.change_name.set(students['name'])
            self.change_math.set(students['数学'])
            self.change_chinese.set(students['语文'])
            self.change_english.set(students['英语'])
        else:
            self.change_status.set('{}用户不存在'.format(name))
```

## 使用(ttkbootstrap)美化ttk程序

> **tk.TK**()和**ttk.Window**()

```
更推荐使用ttk.Window,因为ttk.Window包含了更多的窗口操作命令，可以在后续开发中更方便的使用。
官网地址：
https://ttkbootstrap.readthedocs.io/
```

### Getting Start

```python
import ttkbootstrap as ttk
from ttkbootstrap.constants import *

# 也可以使用themename来指定主题样式，在ttkbootstrap官网中有指定对应的样式
root = ttk.Window(themename='united')
root.title('ttkbootstrap')
root.geometry('500x500')
# bootstyle用于设置按钮的样式
ttk.Button(root, text='complete', bootstyle=SUCCESS).pack()
# OUTLINE用于设置按钮的边框线
ttk.Button(root, text='complete', bootstyle=(SUCCESS, OUTLINE)).pack()

root.mainloop()
```

#### 一个调整条

```
s=tk.Scale(window,
           label='try me',#scale的名字
           from_=5,to=10,#scale的范围
           orient=tk.HORIZONTAL,#定义scale的横向还是竖向
           length=200,#200像素
           showvalue=1,#是否显示当前值
           tickinterval=2,#标记的间隔（每隔多少就显示一个标记）
           resolution=0.1,#精确到0.1位
           command=prints#这个command所用的函数默认有当前值作为参数传入
     )
s.pack()
注意，使用ttk的该参数和tk的参数有所不同，例如showvalue在ttk中就是未知参数
```

**[h for v, h in hobby_list if v.get()]**

## 做一个可以单选并获取内容的单选框

```
self.a = ttk.StringVar()
ttk.Label(text='单选框').pack()
ttk.Radiobutton(text='123', variable=self.a, value='123').pack()
ttk.Radiobutton(text='456', variable=self.a, value='456').pack()
ttk.Radiobutton(text='789', variable=self.a, value='789').pack()
ttk.Button(text='测试', command=lambda: self.text()).pack()

def text(self):
	print(self.a)
```

## 当选项很多时，怎么构建一个滚动的Frame？

```
import ttkbootstrap as ttk
import tkinter as tk
# 导入窗体导航栏
from ttkbootstrap.scrolled import ScrolledFrame

app = ttk.Window()
app.title('测试')
app.geometry('500x500+300+300')
# 构建一个可以滚动的窗体
window = ScrolledFrame(app)
window.pack(expand=True, fill='both')
# 将需要滚动的东西放入滚动窗体内
test_frame = tk.Frame(window)
for x in range(1, 10):
    ttk.Radiobutton(test_frame, text='按钮{}'.format(x)).pack(pady=30)
test_frame.pack()

app.resizable(False, False)
app.mainloop()
```

## 如何制作一个随机数生成？

```python
self.app.after(4000, self.random_text)
在tkinter中如果我们使用传统的函数调用会产生后续的命令无法操作的问题，所以我们使用自带的函数调用来解决这个问题。

# 如果需要加上参数则
self.app.after(4000, self.random_text, x+1)
```

## 如何禁止用户全屏等操作

```python
# 禁止用户全屏
app.resizable(False, False)

# 当用户点击退出按钮时的操作
## 定义一个函数，调用时提示信息
def on_exit():
    messagebox.showwarning(title='提示', message='此路不通')
## 当点击退出时，调用函数
app.protocol('WM_DELETE_WINDOW', on_exit)

# 设置窗体置顶
app.wm_attributes('-topmost', 1)

# 常用的事件处理函数
刷新窗口状态：root.update()
销毁窗口：root.destroy()
自动触发事件：root.after(sec,command)，表示多少秒以后自动执行command
置顶窗口：root.wm_attributes('-topmost',1)
隐藏窗口外部：root.overrideredirect(True)
设置最大的窗口：root.maxsize(600, 400)
设置最小的窗口：root.minsize(300, 240)
设置窗口是否可以缩放（两种方法）： 
root.resizable(width=False, height=False)#禁止改变窗口大小
root.resizable(0, 0) # 设置窗口大小不可变
```

## 项目打包

```
1、将需要打包的内容放在一个文件夹里面
2、创建一个和虚拟环境（打包出来的体积相对较小）
	新建一个虚拟环境`python -m venv venv`
	修改解释器的位置为虚拟环境
	重启终端，通过`pip list`来查看环境是否变更
3、安装打包库`pip install pyinstaller`
4、执行打包指令`pyinstaller xxx.py`

我们通过新建项目的办法也可新建一个环境，但是第三方的包都需要重新下载


pyinstaller -w -i 1.ico -F main.py
```

