---
title: Argparse
date: 2023-03-09 12:13:51
tags:
  - Python
  - 命令行接口开发
  - 理论
category:
  - 开发
mathjax: true
---
# Argparse

> argparse 模块是 Python 内置的用于命令项选项与参数解析的模块，argparse 模块可以让人轻松编写用户友好的命令行接口，能够帮助程序员为模型定义参数。
>

- argparse定义四个步骤
  - 导入argparse包 ——import argparse
  - 创建一个命令行解析器对象 ——创建 ArgumentParser() 对象
  - 如果是有多个子命令还需要多一步 —— 创建parser.add_subparsers() 对象
  - 给解析器添加命令行参数 ——调用add_argument() 方法添加参数
  - 解析命令行的参数 ——使用 parse_args() 解析添加的参数

**实例1：**创建带有create和delete子参数的argparse对象

```python
import argparse

# 实例化
parser = argparse.ArgumentParser()
subprocess = parser.add_subparsers()

# 创建子命令（create）
create_parser = subprocess.add_parser("create")
# 指定参数
create_parser.add_argument("-n", "--name", type=str)
create_parser.add_argument("-i", "--id", type=int, default=1)

# 创建子命令（delete）
delete_parser = subprocess.add_parser("delete")
# 指定参数
delete_parser.add_argument("-n", "--name", type=str)


def create(args):
    print("create", args.name, "id", args.id)


def delete(args):
    print("delete", args.name)


# 指定默认执行函数
create_parser.set_defaults(func=create)
delete_parser.set_defaults(func=delete)

# 解析参数
args = parser.parse_args()
# 执行解析里面的func
args.func(args)
```
