#!/bin/bash
killall hexo
