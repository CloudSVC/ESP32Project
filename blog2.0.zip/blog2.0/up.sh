#!/bin/bash
npx hexo clean

npx hexo g

nohup npx hexo server &
